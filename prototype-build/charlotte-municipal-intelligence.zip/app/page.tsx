'use client';

import React, { useState, useEffect, useRef } from 'react';

// UI STYLES - INSTITUTIONAL FOREST GREEN
const COLORS = {
  forestGreen: '#2e7d32',
  lightGray: '#f0f2f0',
  white: '#ffffff',
  darkGray: '#333333',
  mutedGray: '#888888',
  blue: '#1976d2',
  border: '#dddddd',
  shadow: '0 4px 12px rgba(0,0,0,0.1)',
};

// SVG Road Grid Map of Charlotte
const CharlotteMap = ({ markers = [] }: { markers: { x: number, y: number, label: string }[] }) => (
  <svg viewBox="0 0 400 400" style={{ width: '100%', height: '100%', backgroundColor: '#f8f9f8' }}>
    {/* Grid / Roads */}
    <path d="M 0 100 L 400 100 M 0 200 L 400 200 M 0 300 L 400 300" stroke="#e0e0e0" strokeWidth="1" />
    <path d="M 100 0 L 100 400 M 200 0 L 200 400 M 300 0 L 300 400" stroke="#e0e0e0" strokeWidth="1" />
    <path d="M 50 50 L 350 350 M 350 50 L 50 350" stroke="#eeeeee" strokeWidth="2" />
    <circle cx="200" cy="200" r="100" fill="none" stroke="#f0f0f0" strokeWidth="2" />
    
    {/* Landmarks */}
    <rect x="180" y="180" width="40" height="40" fill="#e8eee8" rx="4" />
    <text x="200" y="210" textAnchor="middle" style={{ fontSize: '8px', fill: '#aaa', fontWeight: 'bold' }}>UPTOWN</text>
    
    {/* Markers (Blue Pins) */}
    {markers.map((m, idx) => (
      <g key={idx} transform={`translate(${m.x}, ${m.y})`}>
        <path d="M 0 0 C -5 -10 -10 -15 -10 -20 A 10 10 0 1 1 10 -20 C 10 -15 5 -10 0 0" fill={COLORS.blue} />
        <circle cx="0" cy="-20" r="4" fill="white" />
        <text y="5" textAnchor="middle" style={{ fontSize: '7px', fill: COLORS.mutedGray, fontWeight: 'bold' }}>{m.label}</text>
      </g>
    ))}
  </svg>
);

export default function CharlotteMunicipalIntelligence() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [activeDept, setActiveDept] = useState('Transportation');
  const [persona, setPersona] = useState('Department Analyst');
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [isPersonaOpen, setIsPersonaOpen] = useState(false);
  
  // Data State per Department
  const depts = [
    { name: 'Transportation', icon: '🚗', color: COLORS.forestGreen },
    { name: 'Water Services', icon: '💧', color: COLORS.forestGreen },
    { name: 'Solid Waste', icon: '🗑️', color: COLORS.forestGreen },
  ];

  const deptData: any = {
    'Transportation': {
      workspace: 'Transit Mobility Ops',
      table: [
        { route: 'I-77 North', score: '82%', id: 'TR-402', issue: 'Congestion' },
        { route: 'Tyvola Rd', score: '94%', id: 'TR-119', issue: 'None' },
        { route: 'Park Rd', score: '61%', id: 'TR-772', issue: 'Signal Delay' },
      ],
      findings: [
        "Evening peak congestion on I-77 requires active ramp metering adjustment.",
        "Park Road signal cycles are out of sync at 3 critical intersections.",
        "Public feedback indicates high satisfaction with Route 12 expansion."
      ],
      markers: [{ x: 200, y: 150, label: 'I-77 North' }, { x: 120, y: 300, label: 'Park Rd' }]
    },
    'Water Services': {
      workspace: 'Aquatic Resource Hub',
      table: [
        { route: 'Zone A-4', score: '98%', id: 'WT-001', issue: 'None' },
        { route: 'Dilworth Main', score: '45%', id: 'WT-223', issue: 'Low Pressure' },
        { route: 'Sugar Creek', score: '88%', id: 'WT-550', issue: 'Turbidity' },
      ],
      findings: [
        "Dilworth water main pressure drop likely due to unmapped private tap-in.",
        "Sugar Creek sensor array triggered secondary alert for sediment levels.",
        "Monthly filtration efficiency remains above 95% target for all sectors."
      ],
      markers: [{ x: 150, y: 220, label: 'Dilworth Main' }, { x: 250, y: 100, label: 'Sugar Creek' }]
    },
    'Solid Waste': {
      workspace: 'Sanitation Analytics',
      table: [
        { route: 'NoDa Loop', score: '72%', id: 'SW-99', issue: 'Vehicle Failure' },
        { route: 'South End', score: '99%', id: 'SW-12', issue: 'None' },
        { route: 'East Side', score: '85%', id: 'SW-33', issue: 'Understaffed' },
      ],
      findings: [
        "NoDa collection loop delayed by hydraulic lift failure on Truck #402.",
        "South End efficiency optimized using dynamic routing software implementation.",
        "Recursive illegal dumping at East Side quadrant 4 requires code enforcement."
      ],
      markers: [{ x: 280, y: 180, label: 'NoDa' }, { x: 180, y: 280, label: 'South End' }]
    }
  };

  const currentData = deptData[activeDept];
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleLogin = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoggedIn(true);
      setIsLoading(false);
      setMessages([{
        role: 'model',
        content: `System ready. Connected as ${persona} for ${activeDept} Division. Reviewing active streams: ${activeDept} Operations Log, Municipal Feedback v2.1.`
      }]);
    }, 800);
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;
    
    const userMsg = input;
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setInput('');
    setIsLoading(true);

    try {
      const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY || '';
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: `Current Date: ${new Date().toLocaleDateString()}
              You are Charlotte Municipal Intelligence (CMI), a secure internal gateway for city staff. You are professional, institutional, and concise. Your goal is to provide strategic intelligence for the ${activeDept} department. 
              Current Persona: ${persona}.
              Connected Data: Internal ${activeDept} Datasets.
              User Query: ${userMsg}
              
              Rules:
              - Keep responses under 150 words.
              - Reference specific operational metrics.
              - Tone should be authoritative but neutral government style.
              - End every response with: "Strategic Intelligence generated via CMI Secure Gateway."`
            }]
          }],
          generationConfig: {
            maxOutputTokens: 500,
          }
        })
      });

      const data = await response.json();
      let text = data.candidates?.[0]?.content?.parts?.[0]?.text || "SYSTEM ERROR: Data connection interrupted. Please verify credentials and retry.";
      
      if (!text.includes("Strategic Intelligence generated")) {
        text += "\n\nStrategic Intelligence generated via CMI Secure Gateway.";
      }

      setMessages(prev => [...prev, { role: 'model', content: text }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', content: "SYSTEM ERROR: Data connection interrupted. Please verify credentials and retry." }]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isLoggedIn) {
    return (
      <div style={{
        height: '100vh',
        width: '100vw',
        backgroundColor: COLORS.forestGreen,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'sans-serif',
        overflow: 'hidden',
        position: 'relative'
      }}>
        <style>{`
          @keyframes float {
            0% { transform: translateY(0); }
            50% { transform: translateY(-12px); }
            100% { transform: translateY(0); }
          }
          @keyframes float-gentle {
            0% { transform: translateY(0); }
            50% { transform: translateY(-4px); }
            100% { transform: translateY(0); }
          }
          @keyframes dot-blink {
            0%, 20% { opacity: 0; }
            50%, 100% { opacity: 1; }
          }
          .floating-crown {
            animation: float 2s ease-in-out infinite;
          }
          .floating-crown-mini {
            animation: float-gentle 2s ease-in-out infinite;
          }
        `}</style>

        {isLoading ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '15px' }}>
            <div className="floating-crown" style={{ fontSize: '52px', color: 'white' }}>♛</div>
            <div style={{ color: 'white', fontSize: '10px', fontWeight: 'bold', letterSpacing: '3px', fontFamily: 'monospace' }}>AUTHENTICATING</div>
            <div style={{ display: 'flex', gap: '4px' }}>
              <div style={{ width: '4px', height: '4px', backgroundColor: 'white', borderRadius: '50%', animation: 'dot-blink 1.4s infinite 0s' }} />
              <div style={{ width: '4px', height: '4px', backgroundColor: 'white', borderRadius: '50%', animation: 'dot-blink 1.4s infinite 0.2s' }} />
              <div style={{ width: '4px', height: '4px', backgroundColor: 'white', borderRadius: '50%', animation: 'dot-blink 1.4s infinite 0.4s' }} />
            </div>
          </div>
        ) : (
          <div style={{
            width: '380px',
            backgroundColor: COLORS.white,
            padding: '40px',
            borderRadius: '12px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.3)',
            textAlign: 'center'
          }}>
            <div style={{
              width: '48px',
              height: '48px',
              backgroundColor: COLORS.forestGreen,
              borderRadius: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px',
              color: 'white',
              fontSize: '24px'
            }}>
              ♛
            </div>
            <h1 style={{ fontSize: '20px', fontWeight: 'bold', margin: '0 0 4px', color: '#1a1a1a' }}>Charlotte Municipal Intelligence</h1>
            <p style={{ fontSize: '12px', color: '#666', margin: '0 0 30px' }}>Secure Access Portal</p>
            
            <form 
              onSubmit={(e) => { e.preventDefault(); handleLogin(); }}
              style={{ textAlign: 'left', marginBottom: '20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '12px', border: '1px solid #eee', borderRadius: '8px', marginBottom: '25px', backgroundColor: '#fafafa' }}>
                <div style={{ width: '20px', height: '20px', borderRadius: '50%', border: `2px solid ${COLORS.forestGreen}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: 'bold', color: COLORS.forestGreen }}>!</div>
                <span style={{ fontSize: '10px', color: '#444', fontWeight: 'bold' }}>ACCESS RESTRICTED TO AUTHORIZED CITY PERSONNEL ONLY</span>
              </div>
              
              <div style={{ marginBottom: '15px' }}>
                <label style={{ fontSize: '10px', fontWeight: 'bold', color: '#555', display: 'block', marginBottom: '6px' }}>OFFICIAL USERNAME</label>
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="name@charlottenc.gov"
                  style={{ width: '100%', padding: '12px', border: '1px solid #ddd', borderRadius: '6px', outline: 'none', fontSize: '14px', color: '#333' }} 
                />
              </div>
              
              <div style={{ marginBottom: '30px' }}>
                <label style={{ fontSize: '10px', fontWeight: 'bold', color: '#555', display: 'block', marginBottom: '6px' }}>ACCESS KEYCODE</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  style={{ width: '100%', padding: '12px', border: '1px solid #ddd', borderRadius: '6px', outline: 'none', fontSize: '14px', color: '#333' }} 
                />
              </div>
              
              <button 
                type="submit"
                style={{ 
                  width: '100%', 
                  padding: '15px', 
                  backgroundColor: COLORS.forestGreen, 
                  color: 'white', 
                  border: 'none', 
                  borderRadius: '6px', 
                  fontWeight: 'bold', 
                  cursor: 'pointer', 
                  letterSpacing: '1px', 
                  fontSize: '15px',
                  transition: 'background-color 0.2s',
                }}
                onMouseOver={(e) => (e.currentTarget.style.backgroundColor = '#1b5e20')}
                onMouseOut={(e) => (e.currentTarget.style.backgroundColor = COLORS.forestGreen)}
              >
                SECURE LOGIN
              </button>
            </form>
            <p style={{ fontSize: '9px', fontWeight: 'bold', color: '#bbb', letterSpacing: '1px', marginTop: '10px' }}>OFFICIAL CITY OF CHARLOTTE INTERNAL TOOL</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: COLORS.lightGray, color: COLORS.darkGray, fontFamily: 'sans-serif' }}>
      <style>{`
          @keyframes float-gentle {
            0% { transform: translateY(0); }
            50% { transform: translateY(-4px); }
            100% { transform: translateY(0); }
          }
          .floating-crown-mini {
            animation: float-gentle 2s ease-in-out infinite;
          }
      `}</style>
      
      <header style={{ height: '60px', backgroundColor: COLORS.white, borderBottom: `1px solid ${COLORS.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', zIndex: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
          <div style={{ fontSize: '24px', color: COLORS.forestGreen }}>♛</div>
          <div>
            <span style={{ fontWeight: '900', letterSpacing: '1px' }}>CHARLOTTE</span>
            <span style={{ color: COLORS.mutedGray, margin: '0 8px' }}>/</span>
            <span style={{ fontSize: '13px', fontWeight: 'bold', color: COLORS.mutedGray }}>Municipal Intelligence</span>
          </div>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <div style={{ position: 'relative' }}>
            <button 
              onClick={() => setIsPersonaOpen(!isPersonaOpen)}
              style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '6px 12px', backgroundColor: '#f8f9f8', border: '1px solid #ddd', borderRadius: '4px', fontSize: '12px', fontWeight: 'bold', cursor: 'pointer' }}>
              {persona}
              <span style={{ fontSize: '10px', transform: isPersonaOpen ? 'rotate(180deg)' : 'none' }}>▼</span>
            </button>
            {isPersonaOpen && (
              <div style={{ position: 'absolute', top: '100%', right: 0, width: '180px', backgroundColor: 'white', border: '1px solid #ddd', boxShadow: COLORS.shadow, borderRadius: '4px', marginTop: '4px' }}>
                {['Department Analyst', 'Director', 'City Manager', 'Administrator'].map(p => (
                  <button key={p} style={{ width: '100%', textAlign: 'left', padding: '10px 15px', border: 'none', background: 'none', fontSize: '12px', cursor: 'pointer', borderBottom: '1px solid #eee' }} onClick={() => { setPersona(p); setIsPersonaOpen(false); }}>{p}</button>
                ))}
              </div>
            )}
          </div>
          <div style={{ padding: '4px 12px', backgroundColor: '#e8f5e9', border: `1px solid ${COLORS.forestGreen}44`, color: COLORS.forestGreen, borderRadius: '20px', fontSize: '10px', fontWeight: 'bold' }}>SESSION: ACTIVE</div>
        </div>
      </header>

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <aside style={{ width: '230px', backgroundColor: COLORS.white, borderRight: `1px solid ${COLORS.border}`, display: 'flex', flexDirection: 'column', padding: '24px 0', overflowY: 'auto' }}>
          <div style={{ padding: '0 24px', marginBottom: '30px' }}>
            <label style={{ fontSize: '10px', fontWeight: 'bold', color: '#888', letterSpacing: '1px', display: 'block', marginBottom: '15px' }}>ACTIVE DEPARTMENT</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {depts.map(d => (
                <button key={d.name} onClick={() => setActiveDept(d.name)} style={{
                    display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 12px', borderRadius: '6px', border: 'none', 
                    backgroundColor: activeDept === d.name ? '#e8f5e9' : 'transparent',
                    color: activeDept === d.name ? COLORS.forestGreen : COLORS.darkGray,
                    fontWeight: activeDept === d.name ? 'bold' : 'normal',
                    fontSize: '13px', cursor: 'pointer', textAlign: 'left'
                  }}>
                  <span>{d.icon}</span> {d.name === 'Solid Waste' ? 'Charlotte Solid Waste' : d.name}
                </button>
              ))}
            </div>
          </div>

          <div style={{ padding: '0 24px', marginBottom: '30px' }}>
            <label style={{ fontSize: '10px', fontWeight: 'bold', color: '#888', letterSpacing: '1px', display: 'block', marginBottom: '12px' }}>ACTIVE DATA SOURCES</label>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {['Internal Fleet Ops', '311 Service Records', 'Spatial Logistics v4'].map(s => (
                <li key={s} style={{ fontSize: '12px', padding: '6px 0', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: COLORS.forestGreen }} /> {s}
                </li>
              ))}
            </ul>
          </div>

          <div style={{ padding: '0 24px', marginBottom: '30px' }}>
            <label style={{ fontSize: '10px', fontWeight: 'bold', color: '#888', letterSpacing: '1px', display: 'block', marginBottom: '12px' }}>OPERATIONAL STATUS</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              {currentData.table.map((row: any, i: number) => (
                <div key={i} style={{ padding: '8px 0', borderBottom: i === currentData.table.length - 1 ? 'none' : '1px solid #f0f0f0' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '3px' }}>
                    <span style={{ fontSize: '11px', fontWeight: 'bold', color: COLORS.darkGray, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '110px' }}>{row.route}</span>
                    <span style={{ fontSize: '9px', fontWeight: 'bold', padding: '2px 6px', color: COLORS.forestGreen, backgroundColor: '#e8f5e9', borderRadius: '4px' }}>{row.score}</span>
                  </div>
                  <div style={{ fontSize: '10px', color: '#999', fontFamily: 'monospace' }}>{row.id}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ padding: '0 24px', marginBottom: '30px' }}>
            <label style={{ fontSize: '10px', fontWeight: 'bold', color: '#888', letterSpacing: '1px', display: 'block', marginBottom: '12px' }}>STRATEGIC RECOMMENDATIONS</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {currentData.findings.map((f: string, i: number) => {
                const words = f.split(' ');
                const label = words.slice(0, 2).join(' ').toUpperCase();
                const body = words.slice(2).join(' ');
                return (
                  <div key={i} style={{ paddingLeft: '8px', borderLeft: '3px solid #a5d6a7' }}>
                    <div style={{ fontSize: '11px', fontWeight: 'bold', color: COLORS.forestGreen, marginBottom: '2px' }}>{label}</div>
                    <div style={{ fontSize: '10px', color: '#888', lineHeight: '1.4' }}>{body}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <div style={{ padding: '0 24px', marginTop: 'auto' }}>
            <label style={{ fontSize: '10px', fontWeight: 'bold', color: '#888', letterSpacing: '1px', display: 'block', marginBottom: '12px' }}>SYSTEM STATUS</label>
            <div style={{ padding: '12px', backgroundColor: '#f8fcf8', border: '1px solid #e0eee0', borderRadius: '8px', marginBottom: '20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#4caf50' }} />
                <span style={{ fontSize: '11px', fontWeight: 'bold' }}>Secure Connection</span>
              </div>
              <p style={{ fontSize: '10px', color: COLORS.mutedGray }}>Verified Node CLT-04</p>
            </div>
            
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderTop: '1px solid #eee' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: '#eee', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', color: '#999', fontSize: '12px' }}>{username[0]?.toUpperCase() || 'U'}</div>
                <span style={{ fontSize: '13px', fontWeight: 'bold' }}>{username.split('@')[0] || 'User'}</span>
              </div>
              <button onClick={() => setIsLoggedIn(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#aaa', fontSize: '18px' }}>➜</button>
            </div>
          </div>
        </aside>

        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', backgroundColor: '#fff', overflow: 'hidden' }}>
          <div style={{ backgroundColor: COLORS.white, padding: '24px 32px', borderBottom: `1px solid ${COLORS.border}` }}>
            <h2 style={{ fontSize: '20px', fontWeight: 'bold', margin: 0 }}>{currentData.workspace}</h2>
            <p style={{ fontSize: '12px', color: COLORS.mutedGray, marginTop: '4px' }}>Department-level operational dashboard for {activeDept}</p>
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: '15px 20px', display: 'flex', flexDirection: 'column', gap: '12px', borderBottom: `1px solid ${COLORS.border}` }}>
             {messages.length === 0 ? (
                <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '32px', color: '#c8e6c9', marginBottom: '8px' }}>♛</div>
                      <div style={{ fontSize: '13px', fontWeight: 'bold', color: '#aaa', marginBottom: '4px' }}>CMI Workspace Ready</div>
                      <div style={{ fontSize: '11px', color: '#ccc', fontFamily: 'monospace' }}>Enter a query in the terminal below</div>
                  </div>
                </div>
             ) : (
                messages.map((m, i) => (
                  <div key={i} style={{ borderBottom: '1px solid #f0f0f0', paddingBottom: '12px' }}>
                    <div style={{ fontSize: '9px', color: '#aaa', fontFamily: 'monospace', marginBottom: '4px', letterSpacing: '0.5px' }}>
                      {m.role === 'user' ? `STAFF · ${persona} · ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : `CMI.SYS · INTERNAL GATEWAY · ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                    </div>
                    <div style={{
                       padding: '4px 0', fontSize: '13px', lineHeight: '1.5',
                       color: COLORS.darkGray,
                       fontFamily: m.role === 'model' ? 'inherit' : 'inherit'
                    }}><div style={{ whiteSpace: 'pre-wrap' }}>{m.content}</div></div>
                  </div>
                ))
             )}
             {isLoading && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                   <div className="floating-crown-mini" style={{ fontSize: '18px', color: COLORS.forestGreen }}>♛</div>
                   <span style={{ fontSize: '10px', color: '#999', fontFamily: 'monospace' }}>Querying secure municipal datasets...</span>
                </div>
             )}
             <div ref={chatEndRef} />
          </div>

          <div style={{ padding: '20px 32px', backgroundColor: '#fcfcfc' }}>
             <label style={{ fontSize: '10px', fontWeight: 'bold', color: COLORS.mutedGray, letterSpacing: '1.5px', display: 'block', marginBottom: '8px' }}>QUERY // {activeDept.toUpperCase()}</label>
             <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
                <textarea 
                  value={input} 
                  onChange={(e) => setInput(e.target.value)} 
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSendMessage())}
                  placeholder="Enter strategic query..." 
                  style={{ 
                    flex: 1, 
                    padding: '12px', 
                    border: '1px solid #ddd', 
                    borderRadius: '4px', 
                    outline: 'none', 
                    fontSize: '13px', 
                    fontFamily: 'Courier New, monospace',
                    minHeight: '60px',
                    resize: 'none',
                    backgroundColor: '#fff'
                  }} 
                />
                <button onClick={handleSendMessage} style={{ padding: '12px 24px', backgroundColor: COLORS.forestGreen, color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '12px', fontWeight: 'bold', letterSpacing: '1px' }}>SEND ↵</button>
              </div>
              <p style={{ fontSize: '9px', color: '#ccc', textAlign: 'left', marginTop: '10px', letterSpacing: '0.5px' }}>SECURE ENCRYPTED NODE // MUNICIPAL INTELLIGENCE ACCESS GRANTED</p>
          </div>
        </main>

        <aside style={{ width: '360px', backgroundColor: COLORS.white, borderLeft: `1px solid ${COLORS.border}`, display: 'flex', flexDirection: 'column' }}>
           <div style={{ padding: '20px 24px', borderBottom: `1px solid ${COLORS.border}`, display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ fontSize: '18px' }}>🗺️</div>
              <h3 style={{ fontSize: '14px', fontWeight: 'bold', margin:0 }}>DETECTED LOCATIONS</h3>
           </div>
           
           <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
              <div style={{ height: '300px', width: '100%', borderBottom: '1px solid #eee', overflow: 'hidden' }}>
                 {currentData.markers.length > 0 ? (
                    <CharlotteMap markers={currentData.markers} />
                 ) : (
                    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '10px' }}>
                       <div style={{ fontSize: '24px' }}>📍</div>
                       <div style={{ fontSize: '11px', color: '#ccc', fontFamily: 'monospace' }}>No locations detected</div>
                    </div>
                 )}
              </div>
              
              <div style={{ flex: 1, padding: '24px', backgroundColor: '#fff' }}>
                 <label style={{ fontSize: '10px', fontWeight: 'bold', color: '#888', letterSpacing: '1px', display: 'block', marginBottom: '15px' }}>ACTIVE MARKERS ({currentData.markers.length})</label>
                 <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {currentData.markers.length > 0 ? currentData.markers.map((m: any, i: number) => (
                       <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: COLORS.blue }} />
                          <p style={{ fontSize: '12px', fontWeight: '500', color: '#333', margin: 0 }}>{m.label}</p>
                       </div>
                    )) : (
                       <div style={{ fontSize: '12px', color: '#ccc' }}>— None —</div>
                    )}
                 </div>
              </div>
           </div>
        </aside>
      </div>
    </div>
  );
}
