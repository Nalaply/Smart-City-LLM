import Link from 'next/link';

export default function NotFound() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh', fontFamily: 'sans-serif' }}>
      <h1>404</h1>
      <p>Page Not Found</p>
      <Link href="/" style={{ color: '#2e7d32', textDecoration: 'underline' }}>Return to Portal</Link>
    </div>
  );
}
